// サンプルデータの投入。`npm run seed` で実行。
// 動作確認用のユーザー・出品・レビューを作る（何度実行しても重複しないよう既存を消してから入れる）。

import db from "./db.js";

console.log("サンプルデータを投入します...");

db.exec(`
  DELETE FROM reviews; DELETE FROM messages; DELETE FROM deals;
  DELETE FROM bids; DELETE FROM listings; DELETE FROM users;
`);

const insertUser = db.prepare("INSERT INTO users (email, name, faculty) VALUES (?, ?, ?)");
const u1 = insertUser.run("sakura@keio.jp", "田中 さくら", "理工学部").lastInsertRowid;
const u2 = insertUser.run("kenta@keio.jp", "佐藤 健太", "経済学部").lastInsertRowid;
const u3 = insertUser.run("misaki@keio.jp", "山本 美咲", "薬学部").lastInsertRowid;

const insertListing = db.prepare(`
  INSERT INTO listings
    (seller_id, title, author, course, faculty, grade, course_type,
     condition, has_writing, notes, meet_spot, sale_type, price, start_price, auction_ends_at)
  VALUES (@seller_id, @title, @author, @course, @faculty, @grade, @course_type,
     @condition, @has_writing, @notes, @meet_spot, @sale_type, @price, @start_price, @auction_ends_at)
`);

insertListing.run({
  seller_id: u1, title: "解析学概論 第3版", author: "高木 貞治", course: "微分積分学A",
  faculty: "理工学部", grade: "1年", course_type: "必修", condition: "良好",
  has_writing: 1, notes: "蛍光ペンの書き込みが数ページあり。折れ・破れなし。",
  meet_spot: "日吉キャンパス 協生館前", sale_type: "fixed", price: 1800,
  start_price: null, auction_ends_at: null,
});

insertListing.run({
  seller_id: u2, title: "ミクロ経済学の力", author: "神取 道宏", course: "ミクロ経済学",
  faculty: "経済学部", grade: "2年", course_type: "選択必修", condition: "非常に良い",
  has_writing: 0, notes: "書き込みなし。カバーに小さなスレあり。",
  meet_spot: "三田キャンパス 南校舎ラウンジ", sale_type: "fixed", price: 2400,
  start_price: null, auction_ends_at: null,
});

insertListing.run({
  seller_id: u3, title: "有機化学 基礎の基礎", author: "齋藤 勝裕", course: "有機化学Ⅰ",
  faculty: "薬学部", grade: "1年", course_type: "必修", condition: "良好",
  has_writing: 1, notes: "重要箇所にマーカー。付箋は剥がして渡します。",
  meet_spot: "芝共立キャンパス 1号館前", sale_type: "auction", price: null,
  start_price: 1000, auction_ends_at: new Date(Date.now() + 3 * 86400000).toISOString(),
});

// レビューを少し（u1 と u2 が高評価）
const insertReview = db.prepare(`
  INSERT INTO reviews (deal_id, reviewer_id, reviewee_id, rating, comment)
  VALUES (?, ?, ?, ?, ?)
`);
// deal を1件だけ作ってレビュー対象にする
const d = db.prepare("INSERT INTO deals (listing_id, buyer_id, seller_id, status) VALUES (1, ?, ?, 'completed')").run(u2, u1).lastInsertRowid;
insertReview.run(d, u2, u1, 5, "とても丁寧な対応でした。状態も説明通り。");

console.log("完了: ユーザー3名・出品3件（販売2 / オークション1）・レビュー1件を投入しました。");
