// データベース接続とスキーマ定義。
// SQLite を使用。テーブル構成はここを見れば全部わかる。
// PostgreSQL へ移行する場合も、このスキーマを基準に置き換えられる。

import Database from "better-sqlite3";
import { mkdirSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const dataDir = join(__dirname, "..", "data");
mkdirSync(dataDir, { recursive: true });

const db = new Database(join(dataDir, "campus-trade.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
-- ユーザー（学内認証済みの学生）
CREATE TABLE IF NOT EXISTS users (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  email       TEXT    UNIQUE NOT NULL,
  name        TEXT    NOT NULL,
  faculty     TEXT,                      -- 学部
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- メール確認コード（ログイン/登録時のワンタイムコード）
CREATE TABLE IF NOT EXISTS email_codes (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  email       TEXT    NOT NULL,
  code        TEXT    NOT NULL,
  expires_at  TEXT    NOT NULL,
  consumed    INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- 出品（教科書）。sale_type で 販売 / オークション を切り替える。
CREATE TABLE IF NOT EXISTS listings (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  seller_id    INTEGER NOT NULL REFERENCES users(id),
  title        TEXT    NOT NULL,         -- 書名
  author       TEXT,                     -- 著者
  course       TEXT,                     -- 授業名
  faculty      TEXT,                     -- 対象学部
  grade        TEXT,                     -- 対象学年
  course_type  TEXT,                     -- 授業特性（必修/選択必修/一般教養 等）
  condition    TEXT,                     -- 状態（良好 など）
  has_writing  INTEGER NOT NULL DEFAULT 0,-- 書き込みの有無
  notes        TEXT,                     -- 補足説明
  meet_spot    TEXT,                     -- 受け渡しスポット（学内）
  sale_type    TEXT    NOT NULL DEFAULT 'fixed', -- 'fixed'(販売) | 'auction'(オークション)
  price        INTEGER,                  -- 販売価格（fixed のとき）
  start_price  INTEGER,                  -- 開始価格（auction のとき）
  auction_ends_at TEXT,                  -- オークション終了日時（auction のとき）
  status       TEXT    NOT NULL DEFAULT 'open', -- 'open' | 'reserved' | 'sold'
  created_at   TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- 入札（オークション用）
CREATE TABLE IF NOT EXISTS bids (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  listing_id  INTEGER NOT NULL REFERENCES listings(id),
  bidder_id   INTEGER NOT NULL REFERENCES users(id),
  amount      INTEGER NOT NULL,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- 取引（買い手と売り手の間の1件）
CREATE TABLE IF NOT EXISTS deals (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  listing_id  INTEGER NOT NULL REFERENCES listings(id),
  buyer_id    INTEGER NOT NULL REFERENCES users(id),
  seller_id   INTEGER NOT NULL REFERENCES users(id),
  meet_spot   TEXT,                      -- 待ち合わせ場所（取引ごとに設定）
  meet_at     TEXT,                      -- 待ち合わせ日時
  status      TEXT    NOT NULL DEFAULT 'negotiating', -- negotiating | agreed | completed | cancelled
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- チャットメッセージ
CREATE TABLE IF NOT EXISTS messages (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  deal_id     INTEGER NOT NULL REFERENCES deals(id),
  sender_id   INTEGER NOT NULL REFERENCES users(id),
  body        TEXT    NOT NULL,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- レビュー（取引相手への相互評価）
CREATE TABLE IF NOT EXISTS reviews (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  deal_id     INTEGER NOT NULL REFERENCES deals(id),
  reviewer_id INTEGER NOT NULL REFERENCES users(id),
  reviewee_id INTEGER NOT NULL REFERENCES users(id),
  rating      INTEGER NOT NULL,          -- 1〜5
  comment     TEXT,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
  UNIQUE(deal_id, reviewer_id)
);

CREATE INDEX IF NOT EXISTS idx_listings_status ON listings(status);
CREATE INDEX IF NOT EXISTS idx_bids_listing   ON bids(listing_id);
CREATE INDEX IF NOT EXISTS idx_messages_deal  ON messages(deal_id);
CREATE INDEX IF NOT EXISTS idx_reviews_reviewee ON reviews(reviewee_id);
`);

export default db;
