// Campus Trade バックエンドのエントリポイント。
// Express を起動し、各 API ルートを /api 以下に登録する。

import "dotenv/config";
import express from "express";
import cors from "cors";

import authRoutes from "./routes/auth.js";
import listingRoutes from "./routes/listings.js";
import dealRoutes from "./routes/deals.js";
import reviewRoutes from "./routes/reviews.js";

const app = express();

app.use(
  cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173" })
);
app.use(express.json());

// 動作確認用
app.get("/api/health", (req, res) => res.json({ ok: true, service: "campus-trade" }));

app.use("/api/auth", authRoutes);
app.use("/api/listings", listingRoutes);
app.use("/api/deals", dealRoutes);
app.use("/api/reviews", reviewRoutes);

// 想定外エラーのフォールバック
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "サーバーでエラーが発生しました" });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Campus Trade API listening on http://localhost:${PORT}`);
  console.log(`  メールモード: ${process.env.MAIL_MODE || "console"}（console の場合、確認コードはこのコンソールに表示されます）`);
});
