// 認証 API。
// 流れ: メール入力 → 確認コードをそのアドレスに送信 → コード検証 → JWT 発行。
// @keio.jp 以外のメールはコード送信前に弾く（学内ドメイン限定）。
//
//   POST /api/auth/request-code   { email }                  → コード送信
//   POST /api/auth/verify-code    { email, code, name? }     → 検証してログイン

import { Router } from "express";
import db from "../db.js";
import { sendVerificationCode } from "../lib/mailer.js";
import { signToken } from "../lib/auth.js";

const router = Router();
const ALLOWED_DOMAIN = process.env.ALLOWED_EMAIL_DOMAIN || "keio.jp";

// 学内ドメインかどうかを判定（サブドメインも許可: a@xxx.keio.jp）
function isAllowedEmail(email) {
  const re = new RegExp(
    `^[^\\s@]+@(?:[a-z0-9-]+\\.)*${ALLOWED_DOMAIN.replace(".", "\\.")}$`,
    "i"
  );
  return re.test(email);
}

function genCode() {
  return String(Math.floor(100000 + Math.random() * 900000)); // 6桁
}

// 確認コードの送信
router.post("/request-code", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();

  if (!email) {
    return res.status(400).json({ error: "メールアドレスを入力してください" });
  }
  if (!isAllowedEmail(email)) {
    return res
      .status(403)
      .json({ error: `慶應義塾大学のメールアドレス（@${ALLOWED_DOMAIN}）でのみ登録できます` });
  }

  const code = genCode();
  const expires = new Date(Date.now() + 10 * 60 * 1000).toISOString(); // 10分

  db.prepare(
    "INSERT INTO email_codes (email, code, expires_at) VALUES (?, ?, ?)"
  ).run(email, code, expires);

  try {
    await sendVerificationCode(email, code);
  } catch (e) {
    console.error("メール送信エラー:", e);
    return res.status(500).json({ error: "確認コードの送信に失敗しました" });
  }

  res.json({ ok: true, message: "確認コードを送信しました" });
});

// 確認コードの検証 → ログイン（初回はユーザー作成）
router.post("/verify-code", (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const code = String(req.body.code || "").trim();
  const name = String(req.body.name || "").trim();

  if (!isAllowedEmail(email)) {
    return res.status(403).json({ error: "学内のメールアドレスではありません" });
  }

  // 未使用かつ有効なコードを新しい順に探す
  const row = db
    .prepare(
      `SELECT * FROM email_codes
       WHERE email = ? AND code = ? AND consumed = 0 AND expires_at > datetime('now')
       ORDER BY id DESC LIMIT 1`
    )
    .get(email, code);

  if (!row) {
    return res.status(400).json({ error: "確認コードが正しくないか、有効期限が切れています" });
  }

  // コードを使用済みにする
  db.prepare("UPDATE email_codes SET consumed = 1 WHERE id = ?").run(row.id);

  // ユーザーを取得、なければ作成
  let user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user) {
    const displayName = name || email.split("@")[0];
    const info = db
      .prepare("INSERT INTO users (email, name) VALUES (?, ?)")
      .run(email, displayName);
    user = db.prepare("SELECT * FROM users WHERE id = ?").get(info.lastInsertRowid);
  }

  const token = signToken(user);
  res.json({
    token,
    user: { id: user.id, email: user.email, name: user.name, faculty: user.faculty },
  });
});

export default router;
