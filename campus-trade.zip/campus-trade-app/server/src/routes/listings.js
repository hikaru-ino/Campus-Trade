// 出品（教科書）の作成・検索・詳細取得、およびオークションの入札。
//
//   GET  /api/listings                  → 一覧（クエリで絞り込み）
//   GET  /api/listings/:id              → 詳細（入札履歴・出品者評価つき）
//   POST /api/listings                  → 出品（要ログイン）販売 or オークション
//   POST /api/listings/:id/bids         → 入札（要ログイン・オークションのみ）

import { Router } from "express";
import db from "../db.js";
import { requireAuth } from "../lib/auth.js";

const router = Router();

// 出品者の平均評価と件数を取得するヘルパ
function sellerRating(sellerId) {
  const r = db
    .prepare(
      `SELECT ROUND(AVG(rating), 1) AS avg, COUNT(*) AS count
       FROM reviews WHERE reviewee_id = ?`
    )
    .get(sellerId);
  return { rating: r.avg || null, reviewCount: r.count || 0 };
}

// 一覧 + 絞り込み検索
router.get("/", (req, res) => {
  const { q, faculty, grade, course_type, sale_type } = req.query;

  const where = ["l.status = 'open'"];
  const params = [];

  if (faculty) { where.push("l.faculty = ?"); params.push(faculty); }
  if (grade) { where.push("l.grade = ?"); params.push(grade); }
  if (course_type) { where.push("l.course_type = ?"); params.push(course_type); }
  if (sale_type) { where.push("l.sale_type = ?"); params.push(sale_type); }
  if (q) {
    where.push("(l.title LIKE ? OR l.author LIKE ? OR l.course LIKE ?)");
    const like = `%${q}%`;
    params.push(like, like, like);
  }

  const rows = db
    .prepare(
      `SELECT l.*, u.name AS seller_name, u.faculty AS seller_faculty
       FROM listings l JOIN users u ON u.id = l.seller_id
       WHERE ${where.join(" AND ")}
       ORDER BY l.created_at DESC`
    )
    .all(...params);

  const listings = rows.map((l) => ({ ...l, seller: sellerRating(l.seller_id) }));
  res.json({ listings });
});

// 詳細
router.get("/:id", (req, res) => {
  const listing = db
    .prepare(
      `SELECT l.*, u.name AS seller_name, u.faculty AS seller_faculty, u.created_at AS seller_joined
       FROM listings l JOIN users u ON u.id = l.seller_id
       WHERE l.id = ?`
    )
    .get(req.params.id);

  if (!listing) return res.status(404).json({ error: "出品が見つかりません" });

  const bids = db
    .prepare(
      `SELECT b.amount, b.created_at, u.name AS bidder_name
       FROM bids b JOIN users u ON u.id = b.bidder_id
       WHERE b.listing_id = ? ORDER BY b.amount DESC`
    )
    .all(listing.id);

  res.json({
    listing: { ...listing, seller: sellerRating(listing.seller_id) },
    bids,
    highestBid: bids[0]?.amount ?? null,
  });
});

// 出品（販売 or オークション）
router.post("/", requireAuth, (req, res) => {
  const b = req.body || {};
  const saleType = b.sale_type === "auction" ? "auction" : "fixed";

  if (!b.title || !String(b.title).trim()) {
    return res.status(400).json({ error: "書名を入力してください" });
  }

  // 形式ごとの必須チェック
  if (saleType === "fixed" && !(Number(b.price) > 0)) {
    return res.status(400).json({ error: "販売価格を入力してください" });
  }
  if (saleType === "auction" && !(Number(b.start_price) >= 0)) {
    return res.status(400).json({ error: "開始価格を入力してください" });
  }

  const info = db
    .prepare(
      `INSERT INTO listings
        (seller_id, title, author, course, faculty, grade, course_type,
         condition, has_writing, notes, meet_spot,
         sale_type, price, start_price, auction_ends_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      req.user.id,
      String(b.title).trim(),
      b.author || null,
      b.course || null,
      b.faculty || null,
      b.grade || null,
      b.course_type || null,
      b.condition || null,
      b.has_writing ? 1 : 0,
      b.notes || null,
      b.meet_spot || null,
      saleType,
      saleType === "fixed" ? Number(b.price) : null,
      saleType === "auction" ? Number(b.start_price) : null,
      saleType === "auction" ? b.auction_ends_at || null : null
    );

  const listing = db.prepare("SELECT * FROM listings WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json({ listing });
});

// 入札（オークションのみ）
router.post("/:id/bids", requireAuth, (req, res) => {
  const listing = db.prepare("SELECT * FROM listings WHERE id = ?").get(req.params.id);
  if (!listing) return res.status(404).json({ error: "出品が見つかりません" });
  if (listing.sale_type !== "auction") {
    return res.status(400).json({ error: "この出品はオークション形式ではありません" });
  }
  if (listing.seller_id === req.user.id) {
    return res.status(400).json({ error: "自分の出品には入札できません" });
  }

  const amount = Number(req.body.amount);
  if (!(amount > 0)) return res.status(400).json({ error: "入札額を入力してください" });

  const current = db
    .prepare("SELECT MAX(amount) AS top FROM bids WHERE listing_id = ?")
    .get(listing.id);
  const floor = current.top ?? listing.start_price ?? 0;
  if (amount <= floor) {
    return res.status(400).json({ error: `現在の最高額（¥${floor.toLocaleString()}）より高い額を入力してください` });
  }

  db.prepare("INSERT INTO bids (listing_id, bidder_id, amount) VALUES (?, ?, ?)")
    .run(listing.id, req.user.id, amount);

  res.status(201).json({ ok: true, highestBid: amount });
});

export default router;
