// レビュー（取引相手への相互評価）。完了した取引に対して、当事者が相手を1〜5で評価する。
//
//   POST /api/reviews                  → レビュー投稿（要ログイン）
//   GET  /api/reviews/user/:userId     → あるユーザーが受け取ったレビュー一覧

import { Router } from "express";
import db from "../db.js";
import { requireAuth } from "../lib/auth.js";

const router = Router();

router.post("/", requireAuth, (req, res) => {
  const dealId = Number(req.body.deal_id);
  const rating = Number(req.body.rating);
  const comment = String(req.body.comment || "").trim();

  if (!(rating >= 1 && rating <= 5)) {
    return res.status(400).json({ error: "評価は1〜5で入力してください" });
  }

  const deal = db.prepare("SELECT * FROM deals WHERE id = ?").get(dealId);
  if (!deal) return res.status(404).json({ error: "取引が見つかりません" });
  if (deal.buyer_id !== req.user.id && deal.seller_id !== req.user.id) {
    return res.status(403).json({ error: "この取引のレビューはできません" });
  }
  if (deal.status !== "completed") {
    return res.status(400).json({ error: "取引完了後にレビューできます" });
  }

  // 評価される相手は取引のもう一方
  const revieweeId = deal.buyer_id === req.user.id ? deal.seller_id : deal.buyer_id;

  // 二重投稿は UNIQUE(deal_id, reviewer_id) で弾く
  try {
    db.prepare(
      `INSERT INTO reviews (deal_id, reviewer_id, reviewee_id, rating, comment)
       VALUES (?, ?, ?, ?, ?)`
    ).run(dealId, req.user.id, revieweeId, rating, comment || null);
  } catch {
    return res.status(409).json({ error: "この取引にはすでにレビュー済みです" });
  }

  res.status(201).json({ ok: true });
});

router.get("/user/:userId", (req, res) => {
  const reviews = db
    .prepare(
      `SELECT r.rating, r.comment, r.created_at, u.name AS reviewer_name
       FROM reviews r JOIN users u ON u.id = r.reviewer_id
       WHERE r.reviewee_id = ? ORDER BY r.id DESC`
    )
    .all(req.params.userId);

  const summary = db
    .prepare(
      "SELECT ROUND(AVG(rating),1) AS avg, COUNT(*) AS count FROM reviews WHERE reviewee_id = ?"
    )
    .get(req.params.userId);

  res.json({ reviews, average: summary.avg || null, count: summary.count || 0 });
});

export default router;
