// 取引（deal）とチャット。
// 出品に対して「取引を開始」すると deal が1件できて、その中でチャット・場所設定・完了まで進む。
//
//   POST /api/deals                       → 取引開始（買い手が出品に対して）
//   GET  /api/deals/:id                   → 取引の詳細（相手・商品・場所・状態）
//   GET  /api/deals/:id/messages          → チャット履歴
//   POST /api/deals/:id/messages          → メッセージ送信
//   PATCH /api/deals/:id/meet             → 待ち合わせ場所・日時の設定
//   POST /api/deals/:id/complete          → 取引完了
//   GET  /api/deals                       → 自分が関わる取引一覧

import { Router } from "express";
import db from "../db.js";
import { requireAuth } from "../lib/auth.js";

const router = Router();

// その取引の当事者（買い手 or 売り手）であることを確認
function loadDealForUser(dealId, userId) {
  const deal = db.prepare("SELECT * FROM deals WHERE id = ?").get(dealId);
  if (!deal) return { error: 404 };
  if (deal.buyer_id !== userId && deal.seller_id !== userId) return { error: 403 };
  return { deal };
}

// 取引開始
router.post("/", requireAuth, (req, res) => {
  const listing = db.prepare("SELECT * FROM listings WHERE id = ?").get(req.body.listing_id);
  if (!listing) return res.status(404).json({ error: "出品が見つかりません" });
  if (listing.seller_id === req.user.id) {
    return res.status(400).json({ error: "自分の出品とは取引できません" });
  }

  // すでに同じ買い手の取引があれば再利用
  const existing = db
    .prepare("SELECT * FROM deals WHERE listing_id = ? AND buyer_id = ?")
    .get(listing.id, req.user.id);
  if (existing) return res.json({ deal: existing });

  const info = db
    .prepare(
      `INSERT INTO deals (listing_id, buyer_id, seller_id, meet_spot)
       VALUES (?, ?, ?, ?)`
    )
    .run(listing.id, req.user.id, listing.seller_id, listing.meet_spot || null);

  const deal = db.prepare("SELECT * FROM deals WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json({ deal });
});

// 自分が関わる取引一覧
router.get("/", requireAuth, (req, res) => {
  const rows = db
    .prepare(
      `SELECT d.*, l.title, l.price, l.sale_type,
              bu.name AS buyer_name, se.name AS seller_name
       FROM deals d
       JOIN listings l ON l.id = d.listing_id
       JOIN users bu ON bu.id = d.buyer_id
       JOIN users se ON se.id = d.seller_id
       WHERE d.buyer_id = ? OR d.seller_id = ?
       ORDER BY d.created_at DESC`
    )
    .all(req.user.id, req.user.id);
  res.json({ deals: rows });
});

// 取引詳細
router.get("/:id", requireAuth, (req, res) => {
  const { deal, error } = loadDealForUser(req.params.id, req.user.id);
  if (error) return res.status(error).json({ error: "取引にアクセスできません" });

  const listing = db.prepare("SELECT * FROM listings WHERE id = ?").get(deal.listing_id);
  const other = db
    .prepare("SELECT id, name, faculty FROM users WHERE id = ?")
    .get(deal.buyer_id === req.user.id ? deal.seller_id : deal.buyer_id);

  res.json({ deal, listing, partner: other, role: deal.buyer_id === req.user.id ? "buyer" : "seller" });
});

// チャット履歴
router.get("/:id/messages", requireAuth, (req, res) => {
  const { error } = loadDealForUser(req.params.id, req.user.id);
  if (error) return res.status(error).json({ error: "取引にアクセスできません" });

  const messages = db
    .prepare(
      `SELECT m.id, m.body, m.created_at, m.sender_id,
              (m.sender_id = ?) AS is_me
       FROM messages m WHERE m.deal_id = ? ORDER BY m.id ASC`
    )
    .all(req.user.id, req.params.id);
  res.json({ messages });
});

// メッセージ送信
router.post("/:id/messages", requireAuth, (req, res) => {
  const { error } = loadDealForUser(req.params.id, req.user.id);
  if (error) return res.status(error).json({ error: "取引にアクセスできません" });

  const body = String(req.body.body || "").trim();
  if (!body) return res.status(400).json({ error: "メッセージを入力してください" });

  const info = db
    .prepare("INSERT INTO messages (deal_id, sender_id, body) VALUES (?, ?, ?)")
    .run(req.params.id, req.user.id, body);
  const message = db.prepare("SELECT * FROM messages WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json({ message });
});

// 待ち合わせ場所・日時の設定
router.patch("/:id/meet", requireAuth, (req, res) => {
  const { deal, error } = loadDealForUser(req.params.id, req.user.id);
  if (error) return res.status(error).json({ error: "取引にアクセスできません" });

  const spot = req.body.meet_spot != null ? String(req.body.meet_spot) : deal.meet_spot;
  const at = req.body.meet_at != null ? String(req.body.meet_at) : deal.meet_at;

  db.prepare("UPDATE deals SET meet_spot = ?, meet_at = ?, status = 'agreed' WHERE id = ?")
    .run(spot, at, deal.id);
  const updated = db.prepare("SELECT * FROM deals WHERE id = ?").get(deal.id);
  res.json({ deal: updated });
});

// 取引完了（出品も sold にする）
router.post("/:id/complete", requireAuth, (req, res) => {
  const { deal, error } = loadDealForUser(req.params.id, req.user.id);
  if (error) return res.status(error).json({ error: "取引にアクセスできません" });

  db.prepare("UPDATE deals SET status = 'completed' WHERE id = ?").run(deal.id);
  db.prepare("UPDATE listings SET status = 'sold' WHERE id = ?").run(deal.listing_id);
  const updated = db.prepare("SELECT * FROM deals WHERE id = ?").get(deal.id);
  res.json({ deal: updated });
});

export default router;
