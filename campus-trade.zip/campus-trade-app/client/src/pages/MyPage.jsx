import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { User, ShieldCheck, Tag, Plus } from "lucide-react";
import { api } from "../lib/api.js";
import { useAuth } from "../lib/auth.jsx";
import { Pill } from "../components/ui.jsx";

const STATUS_LABEL = {
  negotiating: { label: "交渉中", tone: "amber" },
  agreed: { label: "約束済み", tone: "blue" },
  completed: { label: "完了", tone: "green" },
  cancelled: { label: "キャンセル", tone: "stone" },
};

export default function MyPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [deals, setDeals] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.deals().then((d) => setDeals(d.deals)).catch(() => {}).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="flex items-center gap-3 rounded-2xl bg-white p-4 shadow-sm">
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-indigo-100 text-indigo-700">
          <User className="h-6 w-6" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate font-semibold text-stone-800">{user?.name}</p>
          <p className="truncate text-xs text-stone-500">{user?.email}</p>
        </div>
        <Pill tone="green"><ShieldCheck className="h-3 w-3" /> 認証済み</Pill>
      </div>

      <button onClick={() => navigate("/new")}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-indigo-200 bg-indigo-50 py-3 text-sm font-semibold text-indigo-700">
        <Plus className="h-4 w-4" /> 教科書を出品する
      </button>

      <h3 className="mb-3 mt-6 font-bold text-stone-800">取引履歴</h3>
      {loading ? (
        <p className="py-8 text-center text-sm text-stone-400">読み込み中...</p>
      ) : deals.length === 0 ? (
        <p className="rounded-xl border border-dashed border-stone-300 bg-white py-10 text-center text-sm text-stone-400">
          まだ取引がありません
        </p>
      ) : (
        <div className="space-y-2">
          {deals.map((d) => {
            const role = d.buyer_id === user.id ? "購入" : "出品";
            const st = STATUS_LABEL[d.status] || STATUS_LABEL.negotiating;
            return (
              <button key={d.id} onClick={() => navigate(`/chat/${d.id}`)}
                className="flex w-full items-center gap-3 rounded-xl border border-stone-200 bg-white p-3 text-left">
                <span className={`flex h-9 w-9 items-center justify-center rounded-lg ${role === "購入" ? "bg-sky-100 text-sky-700" : "bg-amber-100 text-amber-700"}`}>
                  <Tag className="h-4 w-4" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium text-stone-800">{d.title}</span>
                  <span className="block text-xs text-stone-400">{role}・{d.seller_name} / {d.buyer_name}</span>
                </span>
                <span className="text-right">
                  <span className="block text-sm font-bold text-stone-800">
                    ¥{Number(d.price || 0).toLocaleString()}
                  </span>
                  <Pill tone={st.tone}>{st.label}</Pill>
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
