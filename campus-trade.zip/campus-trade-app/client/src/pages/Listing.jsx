import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  ChevronLeft, BookOpen, ImageIcon, MapPin, User, Gavel, AlertCircle,
} from "lucide-react";
import { api } from "../lib/api.js";
import { Stars, Pill } from "../components/ui.jsx";

export default function Listing() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [bidAmount, setBidAmount] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const load = () => api.listing(id).then(setData).catch(() => setData(false));
  useEffect(() => { load(); }, [id]);

  if (data === false) return <p className="py-12 text-center text-sm text-stone-400">出品が見つかりません</p>;
  if (!data) return <p className="py-12 text-center text-sm text-stone-400">読み込み中...</p>;

  const { listing, bids, highestBid } = data;
  const isAuction = listing.sale_type === "auction";
  const seller = listing.seller || {};

  const startDeal = async () => {
    setBusy(true); setError("");
    try {
      const { deal } = await api.startDeal(listing.id);
      navigate(`/chat/${deal.id}`);
    } catch (e) { setError(e.message); } finally { setBusy(false); }
  };

  const placeBid = async () => {
    setError("");
    if (!(Number(bidAmount) > 0)) return setError("入札額を入力してください");
    setBusy(true);
    try {
      await api.bid(listing.id, Number(bidAmount));
      setBidAmount("");
      await load();
    } catch (e) { setError(e.message); } finally { setBusy(false); }
  };

  const current = highestBid ?? listing.start_price;

  return (
    <div className="pb-28">
      <button onClick={() => navigate(-1)} className="mb-3 flex items-center gap-1 text-sm font-medium text-stone-600">
        <ChevronLeft className="h-4 w-4" /> 戻る
      </button>

      <div className="flex h-48 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-100 to-indigo-50">
        <BookOpen className="h-16 w-16 text-indigo-300" />
      </div>

      <h2 className="mt-4 text-xl font-bold leading-snug text-stone-900">{listing.title}</h2>
      <p className="mt-0.5 text-sm text-stone-500">{listing.author}</p>

      {isAuction ? (
        <div className="mt-3 rounded-xl bg-indigo-50 p-3">
          <div className="flex items-center gap-1.5 text-xs font-medium text-indigo-700">
            <Gavel className="h-3.5 w-3.5" /> オークション開催中
          </div>
          <p className="mt-1 text-2xl font-bold text-stone-900">
            ¥{Number(current || 0).toLocaleString()}
            <span className="ml-2 text-xs font-normal text-stone-500">
              {highestBid ? "現在の最高額" : "開始価格"}
            </span>
          </p>
          <p className="mt-0.5 text-xs text-stone-500">入札 {bids.length} 件</p>
        </div>
      ) : (
        <div className="mt-3 flex items-end gap-2">
          <span className="text-3xl font-bold text-stone-900">¥{Number(listing.price).toLocaleString()}</span>
        </div>
      )}

      <div className="mt-3 flex flex-wrap gap-1.5">
        {listing.faculty && <Pill tone="blue">{listing.faculty}</Pill>}
        {listing.grade && <Pill tone="stone">{listing.grade}</Pill>}
        {listing.course_type && <Pill tone="stone">{listing.course_type}</Pill>}
        {listing.course && <Pill tone="stone">{listing.course}</Pill>}
      </div>

      {/* 状態・書き込み */}
      <section className="mt-5 rounded-xl border border-stone-200 bg-white p-4">
        <h3 className="flex items-center gap-1.5 text-sm font-bold text-stone-800">
          <ImageIcon className="h-4 w-4 text-indigo-600" /> 状態・書き込み
        </h3>
        <div className="mt-3 grid grid-cols-3 gap-2">
          {[0, 1, 2].map((i) => (
            <div key={i} className="flex aspect-square items-center justify-center rounded-lg bg-stone-100 text-[10px] text-stone-400">
              書影 {i + 1}
            </div>
          ))}
        </div>
        <div className="mt-3 flex items-center gap-2">
          {listing.condition && <Pill tone="stone">状態: {listing.condition}</Pill>}
          {listing.has_writing ? <Pill tone="amber">書き込みあり</Pill> : <Pill tone="green">書き込みなし</Pill>}
        </div>
        {listing.notes && <p className="mt-2 text-sm text-stone-600">{listing.notes}</p>}
      </section>

      {/* 出品者 */}
      <section className="mt-4 rounded-xl border border-stone-200 bg-white p-4">
        <h3 className="text-sm font-bold text-stone-800">出品者</h3>
        <div className="mt-3 flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-indigo-100 text-indigo-700">
            <User className="h-5 w-5" />
          </span>
          <div className="flex-1">
            <p className="text-sm font-semibold text-stone-800">{listing.seller_name}</p>
            <p className="text-xs text-stone-500">{listing.seller_faculty}</p>
          </div>
          <div className="text-right">
            <Stars value={seller.rating} />
            <p className="mt-0.5 text-[11px] text-stone-400">レビュー{seller.reviewCount ?? 0}件</p>
          </div>
        </div>
      </section>

      {/* 受け渡し場所 */}
      {listing.meet_spot && (
        <section className="mt-4 rounded-xl border border-stone-200 bg-white p-4">
          <h3 className="flex items-center gap-1.5 text-sm font-bold text-stone-800">
            <MapPin className="h-4 w-4 text-emerald-600" /> 受け渡し場所（対面）
          </h3>
          <p className="mt-2 text-sm text-stone-700">{listing.meet_spot}</p>
          <p className="mt-1 text-xs text-stone-400">学内で直接受け渡し。発送・梱包は不要です。</p>
        </section>
      )}

      {error && (
        <p className="mt-3 flex items-start gap-1.5 text-xs text-rose-600">
          <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {error}
        </p>
      )}

      {/* 下部固定アクション */}
      <div className="fixed inset-x-0 bottom-0 z-20 mx-auto max-w-md border-t border-stone-200 bg-white/95 px-4 py-3 backdrop-blur">
        {isAuction ? (
          <div className="flex gap-2">
            <input
              type="number" value={bidAmount} onChange={(e) => setBidAmount(e.target.value)}
              placeholder={`¥${Number(current || 0).toLocaleString()} より上`}
              className="flex-1 rounded-xl border border-stone-300 px-3 py-3 text-sm outline-none focus:border-indigo-400"
            />
            <button onClick={placeBid} disabled={busy}
              className="flex-[1.2] rounded-xl bg-indigo-900 py-3 text-sm font-semibold text-white disabled:opacity-60">
              入札する
            </button>
          </div>
        ) : (
          <div className="flex gap-2">
            <button onClick={startDeal} disabled={busy}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-indigo-200 bg-indigo-50 py-3 text-sm font-semibold text-indigo-700">
              値引き交渉
            </button>
            <button onClick={startDeal} disabled={busy}
              className="flex-[1.4] rounded-xl bg-indigo-900 py-3 text-sm font-semibold text-white disabled:opacity-60">
              購入手続きへ進む
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
