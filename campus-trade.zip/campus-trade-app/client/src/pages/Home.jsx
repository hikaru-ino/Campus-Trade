import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, ShieldCheck, Wallet, MessageCircle, Plus } from "lucide-react";
import { api } from "../lib/api.js";
import { useAuth } from "../lib/auth.jsx";
import { ListingCard } from "../components/ui.jsx";

export default function Home() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.listings()
      .then((d) => setListings(d.listings.slice(0, 4)))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="rounded-2xl bg-indigo-900 p-6 text-white">
        <p className="text-sm text-indigo-200">こんにちは、{user?.name} さん</p>
        <h2 className="mt-1 text-xl font-bold leading-snug">
          今学期の教科書を<br />学内で見つけよう
        </h2>
        <button
          onClick={() => navigate("/search")}
          className="mt-4 flex w-full items-center gap-2 rounded-xl bg-white/95 px-4 py-3 text-left text-sm text-stone-500 transition hover:bg-white"
        >
          <Search className="h-4 w-4" />
          書名・授業名・キーワードで検索
        </button>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-3">
        {[
          { icon: ShieldCheck, label: "対面取引", sub: "学内で安全に", tone: "text-emerald-600" },
          { icon: Wallet, label: "定価より安い", sub: "中古でお得に", tone: "text-amber-600" },
          { icon: MessageCircle, label: "値引き交渉", sub: "チャットで", tone: "text-sky-600" },
        ].map((c) => (
          <div key={c.label} className="rounded-xl border border-stone-200 bg-white p-3 text-center">
            <c.icon className={`mx-auto h-5 w-5 ${c.tone}`} />
            <p className="mt-1.5 text-xs font-semibold text-stone-800">{c.label}</p>
            <p className="text-[10px] text-stone-500">{c.sub}</p>
          </div>
        ))}
      </div>

      <button
        onClick={() => navigate("/new")}
        className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl border border-indigo-200 bg-indigo-50 py-3 text-sm font-semibold text-indigo-700"
      >
        <Plus className="h-4 w-4" /> 教科書を出品する
      </button>

      <div className="mt-6 flex items-center justify-between">
        <h3 className="font-bold text-stone-800">最近の出品</h3>
        <button onClick={() => navigate("/search")} className="text-xs font-medium text-indigo-700">
          すべて見る
        </button>
      </div>
      <div className="mt-3 space-y-3">
        {loading ? (
          <p className="py-8 text-center text-sm text-stone-400">読み込み中...</p>
        ) : listings.length === 0 ? (
          <p className="py-8 text-center text-sm text-stone-400">まだ出品がありません</p>
        ) : (
          listings.map((l) => (
            <ListingCard key={l.id} listing={l} onClick={() => navigate(`/listing/${l.id}`)} />
          ))
        )}
      </div>
    </div>
  );
}
