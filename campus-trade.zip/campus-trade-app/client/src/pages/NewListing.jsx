import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, AlertCircle, Tag, Gavel } from "lucide-react";
import { api } from "../lib/api.js";

const FACULTIES = ["理工学部", "経済学部", "文学部", "薬学部", "法学部", "その他"];
const GRADES = ["1年", "2年", "3年", "4年", "修士", "その他"];
const COURSE_TYPES = ["必修", "選択必修", "一般教養", "基礎教育科目", "その他"];
const CONDITIONS = ["新品同様", "非常に良い", "良好", "可"];

export default function NewListing() {
  const navigate = useNavigate();
  const [saleType, setSaleType] = useState("fixed"); // fixed | auction
  const [form, setForm] = useState({
    title: "", author: "", course: "", faculty: "", grade: "",
    course_type: "", condition: "良好", has_writing: false, notes: "",
    meet_spot: "", price: "", start_price: "", auction_ends_at: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async () => {
    setError("");
    if (!form.title.trim()) return setError("書名を入力してください");
    if (saleType === "fixed" && !(Number(form.price) > 0)) return setError("販売価格を入力してください");
    if (saleType === "auction" && !(Number(form.start_price) >= 0)) return setError("開始価格を入力してください");

    setLoading(true);
    try {
      const body = {
        ...form,
        sale_type: saleType,
        price: saleType === "fixed" ? Number(form.price) : null,
        start_price: saleType === "auction" ? Number(form.start_price) : null,
      };
      const { listing } = await api.createListing(body);
      navigate(`/listing/${listing.id}`);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pb-6">
      <button onClick={() => navigate(-1)} className="mb-3 flex items-center gap-1 text-sm font-medium text-stone-600">
        <ChevronLeft className="h-4 w-4" /> 戻る
      </button>
      <h2 className="text-lg font-bold text-stone-900">教科書を出品する</h2>

      {/* 取引形式の選択 */}
      <div className="mt-4 grid grid-cols-2 gap-2">
        <button
          onClick={() => setSaleType("fixed")}
          className={`flex flex-col items-center gap-1 rounded-xl border-2 p-3 transition ${
            saleType === "fixed" ? "border-indigo-500 bg-indigo-50" : "border-stone-200 bg-white"
          }`}
        >
          <Tag className={`h-5 w-5 ${saleType === "fixed" ? "text-indigo-600" : "text-stone-400"}`} />
          <span className="text-sm font-semibold text-stone-800">販売</span>
          <span className="text-[10px] text-stone-500">固定価格ですぐ売る</span>
        </button>
        <button
          onClick={() => setSaleType("auction")}
          className={`flex flex-col items-center gap-1 rounded-xl border-2 p-3 transition ${
            saleType === "auction" ? "border-indigo-500 bg-indigo-50" : "border-stone-200 bg-white"
          }`}
        >
          <Gavel className={`h-5 w-5 ${saleType === "auction" ? "text-indigo-600" : "text-stone-400"}`} />
          <span className="text-sm font-semibold text-stone-800">オークション</span>
          <span className="text-[10px] text-stone-500">入札で高く売る</span>
        </button>
      </div>

      <div className="mt-4 space-y-3">
        <Field label="書名 *">
          <input value={form.title} onChange={(e) => set("title", e.target.value)}
            className="input" placeholder="例: 解析学概論 第3版" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="著者">
            <input value={form.author} onChange={(e) => set("author", e.target.value)} className="input" />
          </Field>
          <Field label="授業名">
            <input value={form.course} onChange={(e) => set("course", e.target.value)} className="input" placeholder="微分積分学A" />
          </Field>
        </div>

        <Select label="学部" value={form.faculty} onChange={(v) => set("faculty", v)} options={FACULTIES} />
        <div className="grid grid-cols-2 gap-3">
          <Select label="学年" value={form.grade} onChange={(v) => set("grade", v)} options={GRADES} />
          <Select label="授業特性" value={form.course_type} onChange={(v) => set("course_type", v)} options={COURSE_TYPES} />
        </div>
        <Select label="状態" value={form.condition} onChange={(v) => set("condition", v)} options={CONDITIONS} />

        <label className="flex items-center gap-2 text-sm text-stone-700">
          <input type="checkbox" checked={form.has_writing}
            onChange={(e) => set("has_writing", e.target.checked)} className="h-4 w-4 rounded" />
          書き込み（マーカー・メモ）があります
        </label>

        <Field label="補足説明">
          <textarea value={form.notes} onChange={(e) => set("notes", e.target.value)}
            rows={3} className="input" placeholder="状態や書き込みの詳細など" />
        </Field>

        <Field label="受け渡し場所（学内）">
          <input value={form.meet_spot} onChange={(e) => set("meet_spot", e.target.value)}
            className="input" placeholder="例: 日吉キャンパス 協生館前" />
        </Field>

        {/* 価格（形式によって切り替え） */}
        {saleType === "fixed" ? (
          <Field label="販売価格（円）*">
            <input type="number" value={form.price} onChange={(e) => set("price", e.target.value)}
              className="input" placeholder="1800" />
          </Field>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <Field label="開始価格（円）*">
              <input type="number" value={form.start_price} onChange={(e) => set("start_price", e.target.value)}
                className="input" placeholder="1000" />
            </Field>
            <Field label="終了日時">
              <input type="datetime-local" value={form.auction_ends_at}
                onChange={(e) => set("auction_ends_at", e.target.value)} className="input" />
            </Field>
          </div>
        )}

        {error && (
          <p className="flex items-start gap-1.5 text-xs text-rose-600">
            <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {error}
          </p>
        )}

        <button onClick={submit} disabled={loading}
          className="w-full rounded-xl bg-indigo-900 py-3 text-sm font-semibold text-white transition hover:bg-indigo-800 disabled:opacity-60">
          {loading ? "出品中..." : "この内容で出品する"}
        </button>
      </div>

      <style>{`
        .input {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid #d6d3d1;
          padding: 0.625rem 0.875rem;
          font-size: 0.875rem;
          outline: none;
        }
        .input:focus { border-color: #6366f1; box-shadow: 0 0 0 2px #e0e7ff; }
      `}</style>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="mb-1 block text-xs font-semibold text-stone-500">{label}</label>
      {children}
    </div>
  );
}

function Select({ label, value, onChange, options }) {
  return (
    <Field label={label}>
      <select value={value} onChange={(e) => onChange(e.target.value)} className="input">
        <option value="">選択してください</option>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </Field>
  );
}
