import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Filter } from "lucide-react";
import { api } from "../lib/api.js";
import { ListingCard } from "../components/ui.jsx";

const FACULTIES = ["理工学部", "経済学部", "文学部", "薬学部", "法学部", "その他"];
const GRADES = ["1年", "2年", "3年", "4年", "修士", "その他"];
const COURSE_TYPES = ["必修", "選択必修", "一般教養", "基礎教育科目", "その他"];
const SALE_TYPES = [
  { value: "fixed", label: "販売" },
  { value: "auction", label: "オークション" },
];

export default function SearchPage() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [faculty, setFaculty] = useState("");
  const [grade, setGrade] = useState("");
  const [courseType, setCourseType] = useState("");
  const [saleType, setSaleType] = useState("");
  const [showFilter, setShowFilter] = useState(false);
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);

  // 絞り込み条件が変わるたびに API を叩く
  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => {
      api.listings({ q, faculty, grade, course_type: courseType, sale_type: saleType })
        .then((d) => setListings(d.listings))
        .catch(() => setListings([]))
        .finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(t);
  }, [q, faculty, grade, courseType, saleType]);

  const activeCount = [faculty, grade, courseType, saleType].filter(Boolean).length;
  const clear = () => { setFaculty(""); setGrade(""); setCourseType(""); setSaleType(""); };

  return (
    <div>
      <div className="flex gap-2">
        <div className="flex flex-1 items-center gap-2 rounded-xl border border-stone-300 bg-white px-3">
          <Search className="h-4 w-4 text-stone-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="書名・授業名・著者名"
            className="w-full bg-transparent py-2.5 text-sm outline-none"
          />
        </div>
        <button
          onClick={() => setShowFilter((s) => !s)}
          className={`relative flex items-center gap-1 rounded-xl border px-3 text-sm font-medium ${
            showFilter || activeCount ? "border-indigo-400 bg-indigo-50 text-indigo-700" : "border-stone-300 bg-white text-stone-600"
          }`}
        >
          <Filter className="h-4 w-4" />
          {activeCount > 0 && (
            <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-indigo-600 text-[10px] text-white">
              {activeCount}
            </span>
          )}
        </button>
      </div>

      {showFilter && (
        <div className="mt-3 space-y-3 rounded-xl border border-stone-200 bg-white p-3">
          <FilterRow label="取引形式" options={SALE_TYPES.map((s) => s.label)}
            value={SALE_TYPES.find((s) => s.value === saleType)?.label || ""}
            onChange={(label) => setSaleType(SALE_TYPES.find((s) => s.label === label)?.value || "")} />
          <FilterRow label="学部" options={FACULTIES} value={faculty} onChange={setFaculty} />
          <FilterRow label="学年" options={GRADES} value={grade} onChange={setGrade} />
          <FilterRow label="授業特性" options={COURSE_TYPES} value={courseType} onChange={setCourseType} />
          <button onClick={clear} className="text-xs font-medium text-stone-500 underline">
            条件をクリア
          </button>
        </div>
      )}

      <p className="mb-3 mt-4 text-sm text-stone-500">
        {!loading && listings.length > 0 ? `${listings.length}件の教科書が見つかりました` : ""}
      </p>

      {loading ? (
        <p className="py-8 text-center text-sm text-stone-400">検索中...</p>
      ) : listings.length === 0 ? (
        <div className="rounded-xl border border-dashed border-stone-300 bg-white px-6 py-12 text-center">
          <Search className="mx-auto h-8 w-8 text-stone-300" />
          <p className="mt-3 text-sm font-medium text-stone-600">該当する書籍が見つかりませんでした</p>
          <p className="mt-1 text-xs text-stone-400">条件を変えて再度お試しください</p>
        </div>
      ) : (
        <div className="space-y-3">
          {listings.map((l) => (
            <ListingCard key={l.id} listing={l} onClick={() => navigate(`/listing/${l.id}`)} />
          ))}
        </div>
      )}
    </div>
  );
}

function FilterRow({ label, options, value, onChange }) {
  return (
    <div>
      <p className="mb-1.5 text-xs font-semibold text-stone-500">{label}</p>
      <div className="flex flex-wrap gap-1.5">
        {options.map((o) => (
          <button
            key={o}
            onClick={() => onChange(value === o ? "" : o)}
            className={`rounded-lg px-2.5 py-1 text-xs font-medium transition ${
              value === o ? "bg-indigo-600 text-white" : "bg-stone-100 text-stone-600 hover:bg-stone-200"
            }`}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  );
}
