import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { BookOpen, ShieldCheck, AlertCircle, ArrowLeft } from "lucide-react";
import { api } from "../lib/api.js";
import { useAuth } from "../lib/auth.jsx";

// ログイン: メール入力 → 確認コード送信 → コード検証 の2ステップ。
export default function Login() {
  const [step, setStep] = useState("email"); // email | code
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const requestCode = async () => {
    setError("");
    const value = email.trim().toLowerCase();
    if (!value) return setError("メールアドレスを入力してください");
    setLoading(true);
    try {
      await api.requestCode(value);
      setStep("code");
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const verify = async () => {
    setError("");
    if (!code.trim()) return setError("確認コードを入力してください");
    setLoading(true);
    try {
      const res = await api.verifyCode(email.trim().toLowerCase(), code.trim(), name.trim());
      login(res);
      navigate("/");
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-full items-center justify-center bg-gradient-to-b from-indigo-950 to-indigo-900 px-6 py-16">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-amber-400">
            <BookOpen className="h-8 w-8 text-indigo-950" strokeWidth={2.2} />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Campus Trade</h1>
          <p className="mt-1 text-sm text-indigo-200">慶應生同士で、教科書を安く・早く・安全に</p>
        </div>

        <div className="rounded-2xl bg-white p-6 shadow-xl">
          {step === "email" ? (
            <>
              <label className="block text-sm font-medium text-stone-700">慶應メールアドレス</label>
              <input
                type="email"
                value={email}
                onChange={(e) => { setEmail(e.target.value); setError(""); }}
                onKeyDown={(e) => e.key === "Enter" && requestCode()}
                placeholder="taro@keio.jp"
                className="mt-2 w-full rounded-xl border border-stone-300 px-4 py-3 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
              />
              <label className="mt-3 block text-sm font-medium text-stone-700">
                お名前 <span className="text-xs font-normal text-stone-400">（初回のみ）</span>
              </label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="慶應 太郎"
                className="mt-2 w-full rounded-xl border border-stone-300 px-4 py-3 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
              />
              {error && (
                <p className="mt-2 flex items-start gap-1.5 text-xs text-rose-600">
                  <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {error}
                </p>
              )}
              <button
                onClick={requestCode}
                disabled={loading}
                className="mt-4 w-full rounded-xl bg-indigo-900 py-3 text-sm font-semibold text-white transition hover:bg-indigo-800 active:scale-[0.99] disabled:opacity-60"
              >
                {loading ? "送信中..." : "確認コードを送信"}
              </button>
              <p className="mt-4 flex items-center gap-1.5 text-xs text-stone-500">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
                学内ドメイン（@keio.jp）限定。同じ大学の学生だけが利用できます。
              </p>
            </>
          ) : (
            <>
              <button
                onClick={() => { setStep("email"); setError(""); }}
                className="mb-3 flex items-center gap-1 text-xs font-medium text-stone-500"
              >
                <ArrowLeft className="h-3.5 w-3.5" /> メールアドレスを変更
              </button>
              <p className="text-sm text-stone-600">
                <span className="font-semibold text-stone-800">{email}</span> に送信した
                6桁の確認コードを入力してください。
              </p>
              <input
                value={code}
                onChange={(e) => { setCode(e.target.value.replace(/\D/g, "").slice(0, 6)); setError(""); }}
                onKeyDown={(e) => e.key === "Enter" && verify()}
                placeholder="000000"
                inputMode="numeric"
                className="mt-3 w-full rounded-xl border border-stone-300 px-4 py-3 text-center text-2xl tracking-[0.4em] outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
              />
              {error && (
                <p className="mt-2 flex items-start gap-1.5 text-xs text-rose-600">
                  <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {error}
                </p>
              )}
              <button
                onClick={verify}
                disabled={loading}
                className="mt-4 w-full rounded-xl bg-indigo-900 py-3 text-sm font-semibold text-white transition hover:bg-indigo-800 active:scale-[0.99] disabled:opacity-60"
              >
                {loading ? "確認中..." : "ログイン"}
              </button>
              <p className="mt-3 text-center text-xs text-stone-400">
                ※ 開発モードでは、コードはサーバーのコンソールに表示されます
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
