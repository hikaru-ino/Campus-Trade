import React, { useEffect, useRef, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  ChevronLeft, Send, MapPin, User, CheckCircle2, Star, X,
} from "lucide-react";
import { api } from "../lib/api.js";
import { Stars } from "../components/ui.jsx";

export default function Chat() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [deal, setDeal] = useState(null);
  const [partner, setPartner] = useState(null);
  const [listing, setListing] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [showMeet, setShowMeet] = useState(false);
  const [meetSpot, setMeetSpot] = useState("");
  const [meetAt, setMeetAt] = useState("");
  const [showReview, setShowReview] = useState(false);
  const endRef = useRef(null);

  const loadDeal = () =>
    api.deal(id).then((d) => {
      setDeal(d.deal); setPartner(d.partner); setListing(d.listing);
      setMeetSpot(d.deal.meet_spot || ""); setMeetAt(d.deal.meet_at || "");
    });
  const loadMessages = () => api.messages(id).then((d) => setMessages(d.messages));

  useEffect(() => { loadDeal(); loadMessages(); }, [id]);

  // チャットを2秒ごとにポーリング（簡易リアルタイム）
  useEffect(() => {
    const t = setInterval(loadMessages, 2000);
    return () => clearInterval(t);
  }, [id]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async (text) => {
    const value = (text ?? input).trim();
    if (!value) return;
    setInput("");
    await api.sendMessage(id, value);
    await loadMessages();
  };

  const saveMeet = async () => {
    await api.setMeet(id, meetSpot, meetAt);
    setShowMeet(false);
    await loadDeal();
  };

  const complete = async () => {
    await api.completeDeal(id);
    await loadDeal();
    setShowReview(true);
  };

  if (!deal) return <p className="py-12 text-center text-sm text-stone-400">読み込み中...</p>;

  const completed = deal.status === "completed";

  return (
    <div className="flex h-[calc(100vh-8rem)] flex-col">
      {/* ヘッダ */}
      <div className="-mx-4 -mt-4 flex items-center gap-3 border-b border-stone-200 bg-white px-4 py-3">
        <button onClick={() => navigate(-1)}><ChevronLeft className="h-5 w-5 text-stone-600" /></button>
        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-indigo-100 text-indigo-700">
          <User className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-stone-800">{partner?.name}</p>
          <p className="truncate text-xs text-stone-400">{listing?.title}</p>
        </div>
      </div>

      {/* 取引サマリ */}
      <div className="-mx-4 flex items-center justify-between border-b border-stone-100 bg-stone-50 px-4 py-2.5">
        <button onClick={() => setShowMeet(true)} className="flex items-center gap-1.5 text-xs text-stone-600">
          <MapPin className="h-3.5 w-3.5 text-emerald-600" />
          {deal.meet_spot ? `${deal.meet_spot}${deal.meet_at ? " / " + deal.meet_at : ""}` : "待ち合わせ場所を設定"}
        </button>
        <span className="text-sm font-bold text-stone-800">
          ¥{Number(listing?.price || listing?.start_price || 0).toLocaleString()}
        </span>
      </div>

      {/* メッセージ */}
      <div className="flex-1 space-y-3 overflow-y-auto py-4">
        {messages.length === 0 && (
          <p className="py-8 text-center text-xs text-stone-400">
            メッセージを送って取引を始めましょう
          </p>
        )}
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.is_me ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[78%] rounded-2xl px-3.5 py-2 text-sm ${
              m.is_me ? "rounded-br-sm bg-indigo-900 text-white" : "rounded-bl-sm bg-white text-stone-800 shadow-sm"
            }`}>
              {m.body}
            </div>
          </div>
        ))}
        {completed && (
          <div className="flex justify-center">
            <span className="flex items-center gap-1.5 rounded-full bg-emerald-100 px-3 py-1.5 text-xs font-semibold text-emerald-700">
              <CheckCircle2 className="h-3.5 w-3.5" /> 取引が完了しました
            </span>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* クイック返信 */}
      {!completed && (
        <div className="-mx-4 flex gap-2 overflow-x-auto border-t border-stone-100 px-4 py-2">
          {["受け渡し日時を相談したいです", "もう少しお値引きできますか？", "現地で待ち合わせましょう"].map((q) => (
            <button key={q} onClick={() => send(q)}
              className="shrink-0 rounded-full border border-stone-300 bg-white px-3 py-1.5 text-xs text-stone-600">
              {q}
            </button>
          ))}
        </div>
      )}

      {/* 入力 / 完了ボタン */}
      <div className="-mx-4 -mb-4 border-t border-stone-200 bg-white px-4 py-3">
        {completed ? (
          <button onClick={() => setShowReview(true)}
            className="w-full rounded-xl bg-amber-500 py-3 text-sm font-semibold text-white">
            相手を評価する
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <input
              value={input} onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder="メッセージを入力"
              className="flex-1 rounded-full border border-stone-300 px-4 py-2.5 text-sm outline-none focus:border-indigo-400"
            />
            <button onClick={complete} title="取引完了"
              className="rounded-full border border-emerald-300 bg-emerald-50 px-3 py-2.5 text-xs font-semibold text-emerald-700">
              取引完了
            </button>
            <button onClick={() => send()} className="rounded-full bg-indigo-900 p-2.5 text-white">
              <Send className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>

      {/* 待ち合わせ場所モーダル */}
      {showMeet && (
        <Modal onClose={() => setShowMeet(false)} title="待ち合わせ場所の設定">
          <label className="mb-1 block text-xs font-semibold text-stone-500">場所</label>
          <input value={meetSpot} onChange={(e) => setMeetSpot(e.target.value)}
            placeholder="例: 日吉キャンパス 協生館前"
            className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm outline-none focus:border-indigo-400" />
          <label className="mb-1 mt-3 block text-xs font-semibold text-stone-500">日時</label>
          <input value={meetAt} onChange={(e) => setMeetAt(e.target.value)}
            placeholder="例: 明日 12:30（お昼休み）"
            className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm outline-none focus:border-indigo-400" />
          <button onClick={saveMeet}
            className="mt-4 w-full rounded-xl bg-indigo-900 py-2.5 text-sm font-semibold text-white">
            この場所で合意する
          </button>
        </Modal>
      )}

      {/* レビューモーダル */}
      {showReview && (
        <ReviewModal dealId={Number(id)} partnerName={partner?.name}
          onClose={() => setShowReview(false)} onDone={() => { setShowReview(false); navigate("/mypage"); }} />
      )}
    </div>
  );
}

function Modal({ title, children, onClose }) {
  return (
    <div className="fixed inset-0 z-30 flex items-end justify-center bg-black/40" onClick={onClose}>
      <div className="w-full max-w-md rounded-t-2xl bg-white p-5" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-bold text-stone-800">{title}</h3>
          <button onClick={onClose}><X className="h-5 w-5 text-stone-400" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function ReviewModal({ dealId, partnerName, onClose, onDone }) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true); setError("");
    try {
      await api.createReview(dealId, rating, comment);
      onDone();
    } catch (e) { setError(e.message); setBusy(false); }
  };

  return (
    <Modal title={`${partnerName} さんを評価`} onClose={onClose}>
      <div className="flex justify-center gap-2 py-2">
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} onClick={() => setRating(n)}>
            <Star className={`h-8 w-8 ${n <= rating ? "fill-amber-400 text-amber-400" : "text-stone-300"}`} />
          </button>
        ))}
      </div>
      <textarea value={comment} onChange={(e) => setComment(e.target.value)} rows={3}
        placeholder="取引の感想（任意）"
        className="mt-2 w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm outline-none focus:border-indigo-400" />
      {error && <p className="mt-2 text-xs text-rose-600">{error}</p>}
      <button onClick={submit} disabled={busy}
        className="mt-3 w-full rounded-xl bg-amber-500 py-2.5 text-sm font-semibold text-white disabled:opacity-60">
        評価を送信する
      </button>
    </Modal>
  );
}
