import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./lib/auth.jsx";
import { AppShell } from "./components/ui.jsx";

import Login from "./pages/Login.jsx";
import Home from "./pages/Home.jsx";
import SearchPage from "./pages/Search.jsx";
import NewListing from "./pages/NewListing.jsx";
import Listing from "./pages/Listing.jsx";
import Chat from "./pages/Chat.jsx";
import MyPage from "./pages/MyPage.jsx";

// ログインしていなければ /login に飛ばす
function Protected({ children }) {
  const { isLoggedIn } = useAuth();
  if (!isLoggedIn) return <Navigate to="/login" replace />;
  return <AppShell>{children}</AppShell>;
}

export default function App() {
  const { isLoggedIn } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={isLoggedIn ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/" element={<Protected><Home /></Protected>} />
      <Route path="/search" element={<Protected><SearchPage /></Protected>} />
      <Route path="/new" element={<Protected><NewListing /></Protected>} />
      <Route path="/listing/:id" element={<Protected><Listing /></Protected>} />
      <Route path="/chat/:id" element={<Protected><Chat /></Protected>} />
      <Route path="/mypage" element={<Protected><MyPage /></Protected>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
