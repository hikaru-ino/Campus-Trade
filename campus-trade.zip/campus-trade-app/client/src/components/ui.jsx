import React from "react";
import { Star, BookOpen, Bell, LogOut, Search, User, Home } from "lucide-react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../lib/auth.jsx";

export function Stars({ value, size = 14 }) {
  if (value == null) {
    return <span className="text-xs text-stone-400">評価なし</span>;
  }
  const full = Math.floor(value);
  const half = value - full >= 0.5;
  return (
    <span className="inline-flex items-center gap-0.5 align-middle">
      {[0, 1, 2, 3, 4].map((i) => (
        <Star
          key={i}
          size={size}
          className={
            i < full
              ? "fill-amber-400 text-amber-400"
              : i === full && half
              ? "fill-amber-400/50 text-amber-400"
              : "text-stone-300"
          }
        />
      ))}
      <span className="ml-1 text-xs font-medium text-stone-600">{Number(value).toFixed(1)}</span>
    </span>
  );
}

export function Pill({ children, tone = "stone" }) {
  const tones = {
    stone: "bg-stone-100 text-stone-600",
    green: "bg-emerald-100 text-emerald-700",
    amber: "bg-amber-100 text-amber-700",
    blue: "bg-sky-100 text-sky-700",
    indigo: "bg-indigo-100 text-indigo-700",
  };
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ${tones[tone]}`}>
      {children}
    </span>
  );
}

// アプリ全体の枠（ヘッダ＋下部タブ）。ログイン後の画面で使う。
export function AppShell({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const tabs = [
    { to: "/", icon: Home, label: "ホーム" },
    { to: "/search", icon: Search, label: "さがす" },
    { to: "/mypage", icon: User, label: "マイページ" },
  ];

  return (
    <div className="mx-auto flex min-h-full max-w-md flex-col bg-stone-50">
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-stone-200 bg-white px-4 py-3">
        <Link to="/" className="flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-900">
            <BookOpen className="h-4 w-4 text-amber-400" />
          </span>
          <span className="font-bold tracking-tight text-stone-900">Campus Trade</span>
        </Link>
        <div className="flex items-center gap-3 text-stone-400">
          <button className="relative" title="お知らせ">
            <Bell className="h-5 w-5" />
            <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-rose-500" />
          </button>
          <button onClick={() => { logout(); navigate("/login"); }} title="ログアウト">
            <LogOut className="h-5 w-5" />
          </button>
        </div>
      </header>

      <main className="flex-1 p-4">{children}</main>

      <nav className="sticky bottom-0 grid grid-cols-3 border-t border-stone-200 bg-white">
        {tabs.map((t) => {
          const active = pathname === t.to;
          return (
            <Link
              key={t.to}
              to={t.to}
              className={`flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium transition ${
                active ? "text-indigo-700" : "text-stone-400"
              }`}
            >
              <t.icon className="h-5 w-5" />
              {t.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

// 出品カード（一覧・検索結果で使う）
export function ListingCard({ listing, onClick }) {
  const isAuction = listing.sale_type === "auction";
  const price = isAuction ? listing.start_price : listing.price;
  return (
    <button
      onClick={onClick}
      className="flex w-full gap-3 rounded-xl border border-stone-200 bg-white p-3 text-left transition hover:border-indigo-300 hover:shadow-sm"
    >
      <span className="flex h-20 w-16 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-100 to-indigo-50">
        <BookOpen className="h-7 w-7 text-indigo-400" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate font-semibold text-stone-800">{listing.title}</span>
        <span className="block truncate text-xs text-stone-500">
          {listing.author} ／ {listing.course}
        </span>
        <span className="mt-1.5 flex flex-wrap items-center gap-1.5">
          {listing.faculty && <Pill tone="blue">{listing.faculty}</Pill>}
          {isAuction ? <Pill tone="indigo">オークション</Pill> : null}
          {listing.has_writing ? <Pill tone="amber">書き込みあり</Pill> : <Pill tone="green">書き込みなし</Pill>}
        </span>
        <span className="mt-2 flex items-end justify-between">
          <span>
            <span className="text-[11px] text-stone-400">{isAuction ? "開始 " : ""}</span>
            <span className="text-lg font-bold text-stone-900">¥{Number(price || 0).toLocaleString()}</span>
          </span>
          <Stars value={listing.seller?.rating} size={12} />
        </span>
      </span>
    </button>
  );
}
